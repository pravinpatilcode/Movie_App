const movieSchema = require("../models/movieSchema")

module.exports = {

    /*
apiName - addMovie
apiType - POST
*/

    addMovie: async (req, res) => {

        const movieData = new movieSchema(req.body);

        try {
            const movie = await movieData.save();
            res.status(201).json({
                success: true,
                message: "Movie addedd Sucessfully",
                movie: movie,
            });
        } catch (error) {
            res.status(500).json({
                success: false,
                message: `Error occur ${error.message}`,
            });
        }
    },


    /*
    apiName - movieList
    apiType - GET
    */
    movieList: async (req, res) => {
        try {
            let movies = await movieSchema.find();
            if (movies.length > 0) {
                const filteredData = movies.map(item => ({
                    movieName: item.movieName,
                    directorName: item.directorName,
                    leadRole: item.leadRole,
                    id: item.id
                }));
                res.status(200).json({
                    success: true,
                    message: "All movies list",
                    movies: filteredData,
                });
            } else {
                res.status(404).json({
                    success: true,
                    message: "No movies",
                });
            }
        } catch (error) {
            res.status(500).json({
                success: false,
                error: error,
            });
        }
    },

    /*
    apiName - movieListById
    apiType - GET
    */
    movieListById: async (req, res) => {
        try {
           let movieName = req.body.movieName;
           let movies = await movieSchema.find({
                movieName: movieName ,
              });
             if (movies.length > 0) {
                const filteredData = movies.map(item => ({
                    movieName: item.movieName,
                    directorName: item.directorName,
                    leadRole: item.leadRole,
                }));
                res.status(200).json({
                    success: true,
                    message: " Movies Data",
                    movies: filteredData,
                });
            } else {
                res.status(404).json({
                    success: true,
                    message: "No movies",
                });
            }
        } catch (error) {
            res.status(500).json({
                success: false,
                error: error,
            });
        }
    },

    /*
    apiName - updateMovieById
    apiType - PUT
    */

    updateMovieById: async (req, res) => {
        let id = req.params.id;
        try {
        let updateMovie = await movieSchema.findByIdAndUpdate(
                id,
                req.body,
                {
                  new: true,
                }
              );
            res.status(202).send({
                success: true,
                message: "Movie updated Succesfully",
                update: updateMovie,
            });
        } catch (error) {
            res.status(500).send({
                success: false,
                error: error,
            });
        }
    },


    /*
    apiName - deleteMovieById
    apiType - DELETE
    */

    deleteMovieById: async (req, res) => {
        let id = req.params.id;
        try {
            let deleteMovie = await movieSchema.findByIdAndDelete(
                id,
                {
                    new: true,
                }
            );
            res.status(202).send({
                success: true,
                message: "Movie delete Succesfully",
                delete: deleteMovie,
            });
        } catch (error) {
            res.status(500).send({
                success: false,
                error: error,
            });
        }
    }
}

