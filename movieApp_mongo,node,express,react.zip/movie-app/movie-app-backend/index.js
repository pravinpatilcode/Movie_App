require("dotenv").config();
let express = require("express");

require("./config/modelConfig");


let movieRouter = require("./routes/movieRoutes");
const cors = require('cors');
let app = express();
app.use(cors());
app.use(express.json());
 app.use("/", movieRouter);


app.listen(process.env.PORT, (req, res) => {
  console.log(`server is running on PORT:${process.env.PORT}`);
});