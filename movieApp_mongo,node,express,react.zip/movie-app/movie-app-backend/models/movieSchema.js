const mongoose = require("mongoose");

const movieSchema = mongoose.Schema({
  
  movieName: {
    type: String,
    required: true,
  },
  directorName: {
    type: String,
    required: true,
  },
  leadRole: {
    type: String,
    required: true,
  },
  isActive: {
    type: String,
    default: true,
  },
});
movieSchema.set("timestamps", true);

module.exports = mongoose.model("movie", movieSchema);