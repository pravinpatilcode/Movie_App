const express = require("express");

const {addMovie, movieList, movieListById, updateMovieById, deleteMovieById} = require("../controllers/movieController")

const movieRouter = express.Router();

movieRouter.post("/add-movie", addMovie);
movieRouter.get("/get-movie", movieList);
movieRouter.get("/get-movie-id", movieListById);
movieRouter.put("/update-movie-id/:id", updateMovieById);
movieRouter.delete("/delete-movie-id/:id", deleteMovieById);

module.exports = movieRouter