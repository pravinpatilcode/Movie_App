import MoviesList from "./Components/Movies_list";

function App() {
  return (
    <div style={{ height: "100vh" }}>
      <MoviesList />
    </div>
  );
}

export default App;
