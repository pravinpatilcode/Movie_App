import {
  Box,
  Button,
  Dialog,
  DialogActions,
  DialogContent,
  DialogTitle,
  TextField,
} from "@mui/material";
import React from "react";
import "./AddMoviesDialog.css";
import axios from "axios";
const AddMoviesDialog = ({ open, handleClose, setIsBool, isBool }) => {
  let baseUrl = process.env.REACT_APP_API_URL;

  const handleSubmit = async (event) => {
    event.preventDefault();
    const data = new FormData(event.currentTarget);
    try {
      await axios.post(`${baseUrl}add-movie`, {
        movieName: data.get("Movie"),
        directorName: data.get("Director"),
        leadRole: data.get("Lead_Role"),
      });
      setIsBool(!isBool);
      handleClose();
    } catch (error) {
      console.error(error);
    }
  };

  return (
    <div>
      <Dialog
        open={open}
        onClose={handleClose}
        aria-labelledby="alert-dialog-title"
        aria-describedby="alert-dialog-description"
        className="movies-dialog-container">
        <DialogTitle id="alert-dialog-title" sx={{ fontWeight: "bold" }}>
          Add Movies
        </DialogTitle>
        <Box component="form" onSubmit={handleSubmit} noValidate>
          <DialogContent
            sx={{ display: "flex", flexDirection: "column", gap: "10px" }}>
            <TextField
              type="text"
              required
              fullWidth
              id="Movie"
              name="Movie"
              autoComplete="Movie"
              autoFocus
              label="Movie Name"
              sx={{ mt: "10px" }}
            />
            <TextField
              type="text"
              required
              fullWidth
              id="Director"
              name="Director"
              autoComplete="Director"
              autoFocus
              label="Director Name"
            />
            <TextField
              type="text"
              required
              fullWidth
              id="Lead_Role"
              name="Lead_Role"
              autoComplete="Lead_Role"
              autoFocus
              label="Lead Role Name"
            />
          </DialogContent>
          <DialogActions>
            <Button onClick={handleClose} variant="outlined">
              Cancel
            </Button>
            <Button type="submit" autoFocus variant="outlined">
              Submit
            </Button>
          </DialogActions>
        </Box>
      </Dialog>
    </div>
  );
};

export default AddMoviesDialog;
