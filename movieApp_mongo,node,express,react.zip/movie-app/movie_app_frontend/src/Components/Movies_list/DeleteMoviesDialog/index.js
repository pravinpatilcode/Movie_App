import {
  Box,
  Button,
  Dialog,
  DialogActions,
  DialogContent,
  DialogTitle,
} from "@mui/material";
import React from "react";
import "../AddMoviesDialog/AddMoviesDialog.css";
import ErrorOutlineIcon from "@mui/icons-material/ErrorOutline";
import axios from "axios";

const DeleteMoviesDialog = ({
  openDelete,
  handleDeleteClose,
  moviesID,
  setIsBool,
  isBool,
}) => {
  let baseUrl = process.env.REACT_APP_API_URL;
  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      await axios.delete(`${baseUrl}delete-movie-id/${moviesID}`);
      handleDeleteClose();
      setIsBool(!isBool);
    } catch (error) {
      console.error("Error deleting movie: ", error);
    }
  };

  return (
    <div>
      <Dialog
        open={openDelete}
        onClose={handleDeleteClose}
        aria-labelledby="alert-dialog-title"
        aria-describedby="alert-dialog-description"
        className="movies-dialog-container">
        <Box component="form" onSubmit={handleSubmit} noValidate>
          <DialogContent
            sx={{
              display: "flex",
              flexDirection: "column",
              gap: "10px",
            }}>
            <Box component="div" sx={{ textAlign: "center" }}>
              <ErrorOutlineIcon
                sx={{ width: "200px", height: "100px", color: "red" }}
              />
              <div style={{ fontSize: "20px" }}>
                Are you sure you need to delete ?
              </div>
            </Box>
          </DialogContent>
          <DialogActions
            sx={{
              display: "flex",
              justifyContent: "space-around",
            }}>
            <Button onClick={handleDeleteClose} variant="outlined">
              Cancel
            </Button>
            <Button
              type="submit"
              autoFocus
              variant="outlined"
              sx={{
                borderColor: "red",
                color: "red",
                "&:hover": {
                  borderColor: "red",
                  background: "transparent",
                },
              }}>
              Delete
            </Button>
          </DialogActions>
        </Box>
      </Dialog>
    </div>
  );
};

export default DeleteMoviesDialog;
