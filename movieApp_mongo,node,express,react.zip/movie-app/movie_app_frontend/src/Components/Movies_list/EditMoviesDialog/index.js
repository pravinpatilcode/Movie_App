import {
  Box,
  Button,
  Dialog,
  DialogActions,
  DialogContent,
  DialogTitle,
  TextField,
} from "@mui/material";
import React from "react";
import "../AddMoviesDialog/AddMoviesDialog.css";
import axios from "axios";

const EditMoviesDialog = ({ openEdit, handleEditClose, setIsBool, isBool ,movieData}) => {
  let baseUrl = process.env.REACT_APP_API_URL;

  const handleSubmit = async(event) => {
    event.preventDefault();
    const data = new FormData(event.currentTarget);
    try {
      await axios.put(`${baseUrl}update-movie-id/${movieData?.id}`, {
        movieName: data.get("Movie"),
        directorName: data.get("Director"),
        leadRole: data.get("Lead_Role"),
      });
      setIsBool(!isBool);
      handleEditClose();
  } catch (error) {
    console.error(error);
  }
  }
  return (
    <div>
      <Dialog
        open={openEdit}
        onClose={handleEditClose}
        aria-labelledby="alert-dialog-title"
        aria-describedby="alert-dialog-description"
        className="movies-dialog-container">
        <DialogTitle id="alert-dialog-title" sx={{ fontWeight: "bold" }}>
          Edit Movies
        </DialogTitle>
        <Box component="form" onSubmit={handleSubmit} noValidate>
          <DialogContent
            sx={{ display: "flex", flexDirection: "column", gap: "10px" }}>
            <TextField
              type="text"
              required
              fullWidth
              id="Movie"
              name="Movie"
              defaultValue={movieData?.movieName}
              autoComplete="Movie"
              autoFocus
              label="Movie Name"
              sx={{ mt: "10px" }}
            />
            <TextField
              type="text"
              required
              fullWidth
              id="Director"
              name="Director"
              defaultValue={movieData?.directorName}
              autoComplete="Director"
              autoFocus
              label="Director Name"
            />
            <TextField
              type="text"
              required
              fullWidth
              id="Lead_Role"
              name="Lead_Role"
              autoComplete="Lead_Role"
              defaultValue={movieData?.leadRole}
              autoFocus
              label="Lead Role Name"
            />
          </DialogContent>
          <DialogActions>
            <Button onClick={handleEditClose} variant="outlined">
              Cancel
            </Button>
            <Button type="submit" autoFocus variant="outlined">
              Submit
            </Button>
          </DialogActions>
        </Box>
      </Dialog>
    </div>
  );
};

export default EditMoviesDialog;
