import Table from "@mui/material/Table";
import TableBody from "@mui/material/TableBody";
import TableCell from "@mui/material/TableCell";
import TableContainer from "@mui/material/TableContainer";
import TableHead from "@mui/material/TableHead";
import TableRow from "@mui/material/TableRow";
import Paper from "@mui/material/Paper";
import { Box, Button, IconButton, MenuItem, TextField } from "@mui/material";
import AddMoviesDialog from "./AddMoviesDialog";
import { useEffect, useState } from "react";
import EditIcon from "@mui/icons-material/Edit";
import DeleteIcon from "@mui/icons-material/Delete";
import DeleteMoviesDialog from "./DeleteMoviesDialog";
import EditMoviesDialog from "./EditMoviesDialog";
import axios from "axios";

const MoviesList = () => {
  const [open, setOpen] = useState(false);
  const [openDelete, setOpenDelete] = useState(false);
  const [openEdit, setOpenEdit] = useState(false);
  const [isBool, setIsBool] = useState(false);
  const [moviesData, setMoviesData] = useState([]);
  const [movieData, setMovieData] = useState({});
  const [moviesID, setMoviesID] = useState("");
  const [searchValue, setSearchValue] = useState("");

  let baseUrl = process.env.REACT_APP_API_URL;

  const handleClickDeleteOpen = (id) => {
    setMoviesID(id);
    setOpenDelete(true);
  };

  const handleDeleteClose = () => {
    setOpenDelete(false);
  };
  const handleClickEditOpen = (data) => {
    setMovieData(data);
    setOpenEdit(true);
  };

  const handleEditClose = () => {
    setOpenEdit(false);
  };

  const handleClose = () => {
    setOpen(false);
  };

  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await axios.get(`${baseUrl}get-movie`, {
          headers: {
            "Access-Control-Allow-Origin": "*",
          },
        });
        setMoviesData(response?.data?.movies);
      } catch (error) {
        console.error(error);
      }
    };

    fetchData();
  }, [isBool]);

  return (
    <div
      style={{
        height: "100%",
        background: "black",
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
      }}>
      <Box
        component="div"
        sx={{
          maxWidth: "1280px",
          display: "flex",
          justifyContent: "space-between",
          width: "100%",
          alignItems: "center",
        }}>
        <Button
          onClick={() => setOpen(true)}
          sx={{ height: "40px", color: "white", bgcolor: "blue" }}
          variant="outlined">
          Add
        </Button>
      </Box>
      <TableContainer component={Paper} sx={{ maxWidth: "1280px" }}>
        <Table sx={{ minWidth: 650 }} aria-label="simple table">
          <TableHead>
            <TableRow>
              <TableCell
                align="center"
                sx={{ fontWeight: "bold", width: "50px", fontSize: "16px" }}>
                S.N0.
              </TableCell>
              <TableCell
                align="center"
                sx={{ fontWeight: "bold", fontSize: "16px" }}>
                Movies
              </TableCell>
              <TableCell
                align="center"
                sx={{ fontWeight: "bold", fontSize: "16px" }}>
                Lead Role
              </TableCell>
              <TableCell
                align="center"
                sx={{ fontWeight: "bold", fontSize: "16px" }}>
                Directors
              </TableCell>
              <TableCell
                align="center"
                sx={{ fontWeight: "bold", fontSize: "16px" }}>
                Action
              </TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {moviesData &&
              moviesData.length &&
              moviesData.map((item, index) => (
                <TableRow
                  key={index}
                  sx={{ "&:last-child td, &:last-child th": { border: 0 } }}>
                  <TableCell
                    component="th"
                    scope="row"
                    align="center"
                    sx={{ fontWeight: "bold", width: "50px" }}>
                    {index + 1}
                  </TableCell>
                  <TableCell align="center">{item?.movieName}</TableCell>
                  <TableCell align="center">{item?.leadRole}</TableCell>
                  <TableCell align="center">{item?.directorName}</TableCell>
                  <TableCell
                    align="center"
                    sx={{
                      display: "flex",
                      justifyContent: "center",
                      gap: "5px",
                    }}>
                    <IconButton onClick={() => handleClickEditOpen(item)}>
                      <EditIcon />
                    </IconButton>
                    <IconButton onClick={() => handleClickDeleteOpen(item?.id)}>
                      <DeleteIcon />
                    </IconButton>
                  </TableCell>
                </TableRow>
              ))}
          </TableBody>
        </Table>
      </TableContainer>
      <AddMoviesDialog
        open={open}
        handleClose={handleClose}
        setIsBool={setIsBool}
        isBool={isBool}
      />
      <DeleteMoviesDialog
        openDelete={openDelete}
        handleDeleteClose={handleDeleteClose}
        moviesID={moviesID}
        setIsBool={setIsBool}
        isBool={isBool}
      />
      <EditMoviesDialog
        openEdit={openEdit}
        handleEditClose={handleEditClose}
        movieData={movieData}
        setIsBool={setIsBool}
        isBool={isBool}
      />
    </div>
  );
};

export default MoviesList;
